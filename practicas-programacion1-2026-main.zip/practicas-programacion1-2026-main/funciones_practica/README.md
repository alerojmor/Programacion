# Practica de Funciones

Guia de ejercicios autoevaluable. Tu tarea es completar las 10 funciones
del archivo `funciones.cpp` y verificar que todas pasen los tests.

## Archivos

- **funciones.cpp** &rarr; El unico archivo que tenes que editar. Contiene
  las 10 funciones para completar.
- **test_funciones.cpp** &rarr; Tests automaticos. NO modificar.
- **Makefile** &rarr; Automatiza la compilacion y la ejecucion (opcional).
- **.gitignore** &rarr; Para que Git no suba al repo los archivos compilados.

## Importante: que archivo compilo?

Siempre se compila **`test_funciones.cpp`**, NO `funciones.cpp`.

Si trabajan desde Visual Studio Code y usan el boton "Run Code" o algun
atajo de teclado para compilar y ejecutar, asegurense de tener abierto
**`test_funciones.cpp`** al momento de apretar el boton. Si lo hacen sobre
`funciones.cpp` van a obtener un error parecido a:

```
undefined reference to `main`
```

Eso ocurre porque `funciones.cpp` no tiene un `main()`: el `main()` esta
adentro de `test_funciones.cpp`, que es justamente el archivo que se
encarga de invocar tus funciones y mostrar los resultados.

### Y como sabe el test sobre mis funciones?

Si miran las primeras lineas de `test_funciones.cpp`, van a ver:

```cpp
#include "funciones.cpp"
```

Eso le indica al compilador que, antes de compilar, "pegue" el contenido
de `funciones.cpp` adentro del archivo de tests. Asi, al compilar
`test_funciones.cpp`, ya quedan disponibles todas las funciones que
ustedes escribieron.

## Como probar tu trabajo

### Opcion A: Desde Visual Studio Code

1. Abri **`test_funciones.cpp`** (no `funciones.cpp`).
2. Compila y ejecuta con el boton "Run Code" o tu atajo habitual.
3. Mira los resultados en la terminal integrada.

### Opcion B: Desde la terminal con make

Parados en la carpeta del proyecto:

```bash
make
```

Eso compila y corre los tests de una sola vez.

Para borrar el archivo compilado:

```bash
make clean
```

### Opcion C: Desde la terminal sin make

```bash
g++ test_funciones.cpp -o a.out
./a.out
```

(En Windows, el ejecutable se va a llamar `a.exe` y se invoca con `.\a.exe`)

## Como leer los resultados

Vas a ver algo asi:

```
==========================================
  Tests - Guia de ejercicios: Funciones
==========================================

Ejercicio 1 - calcularCuadrado()
  [PASA] cuadrado de 5
  [PASA] cuadrado de 0
  [FALLA] cuadrado de -3  -> esperado: 9, obtenido: 0
  [FALLA] cuadrado de 10  -> esperado: 100, obtenido: 0
...
==========================================
  RESUMEN: 2 / 4 tests pasaron
  Te quedan 2 test(s) por arreglar.
==========================================
```

Cuando termines, los 42 tests tienen que pasar.

## Recomendaciones

- Trabajen ejercicio por ejercicio. No traten de hacer los 10 de una.
- Cuando un test falla, leen bien que valor esperaba y cual dio su funcion:
  ahi suele estar la pista del error.
- No usen `cin` dentro de las funciones: las funciones reciben datos por
  parametro y deben devolver un valor con `return`.
- No cambien los nombres de las funciones ni los tipos de los parametros
  o del retorno: si lo hacen, los tests no van a poder ejecutarse.

## Si algo no compila

Si al compilar aparece un error (en rojo o que diga "error"), copien el
mensaje y revisen el numero de linea que indica. Casi siempre se trata
de un punto y coma faltante, una llave sin cerrar o un nombre mal escrito.

Si el error es `undefined reference to main`: estan compilando el archivo
equivocado. Compilen `test_funciones.cpp`, no `funciones.cpp`.
