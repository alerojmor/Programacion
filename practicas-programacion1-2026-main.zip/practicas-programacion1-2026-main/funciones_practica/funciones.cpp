/*
Nombre de archivo: funciones.cpp (No cambiar el nombre de este archivo)

INSTRUCCIONES
-------------
Tu tarea es completar las 10 funciones que estan declaradas mas abajo.
NO tenes que escribir un main aca: el main esta en el archivo test_funciones.cpp
y lo que va a hacer es invocar tus funciones y comparar el resultado contra
los valores esperados.



Notas importantes:
- No cambies los nombres de las funciones ni la cantidad/tipo de parametros.
- No cambies los tipos de retorno.
- Las funciones reciben los datos por parametro: NO uses cin adentro de las
  funciones (eso lo haria un main, pero aca no nos importa la interaccion
  con el usuario, solo que la funcion calcule bien).
- Siempre se compila **`test_funciones.cpp`**, NO `funciones.cpp`.
*/

#include <iostream>
using namespace std;


/* 1. POTENCIA
   Recibe un numero entero y retorna su cuadrado.
   Ejemplo: calcularCuadrado(5) debe retornar 25.
*/
int calcularCuadrado(int numero) {
    // TODO: completar
    return;
}


/* 2. EL MAYOR DE TRES
   Recibe tres numeros enteros y retorna el mayor de los tres.
   Ejemplo: maximoDeTres(3, 7, 5) debe retornar 7.
*/
int maximoDeTres(int a, int b, int c) {
    // TODO: completar
    return;
}


/* 3. CONVERSION DE CLIMA
   Recibe una temperatura en grados Celsius y retorna su equivalente
   en grados Fahrenheit.
   Formula: F = C * 9/5 + 32
   Ejemplo: celsiusAFahrenheit(0.0) debe retornar 32.0
            celsiusAFahrenheit(100.0) debe retornar 212.0
*/
float celsiusAFahrenheit(float celsius) {
    // TODO: completar
    return;
}


/* 4. VALIDACION DE PARIDAD
   Recibe un numero entero y retorna true si es par, false si es impar.
   Ejemplo: esPar(4) debe retornar true.
            esPar(7) debe retornar false.
*/
bool esPar(int numero) {
    // TODO: completar
    return;
}


/* 5. CALCULO DE IVA
   Recibe el precio de un producto (sin IVA) y retorna el precio
   final con IVA del 21% incluido.
   Ejemplo: aplicarIVA(100.0) debe retornar 121.0
*/
float aplicarIVA(float precio) {
    // TODO: completar
    return;
}


/* 6. COMPUTO DE PROMEDIO
   Recibe tres notas (numeros enteros) y retorna el promedio.
   Ejemplo: obtenerPromedio(7, 8, 10) debe retornar 8.33 (aprox).
*/
float obtenerPromedio(int nota1, int nota2, int nota3) {
    // TODO: completar
    return;
}


/* 7. SIGNO NUMERICO
   Recibe un numero entero y retorna:
      1  si es positivo
      0  si es cero
     -1  si es negativo
*/
int determinarSigno(int numero) {
    // TODO: completar
    return;
}


/* 8. CONVERSOR DE DISTANCIA
   Recibe una distancia en metros y retorna su equivalente en kilometros.
   Ejemplo: metrosAKilometros(1500.0) debe retornar 1.5
*/
float metrosAKilometros(float metros) {
    // TODO: completar
    return;
}


/* 9. LOGICA DE DESCUENTO
   Recibe un precio y un porcentaje de descuento, y retorna el precio
   final con el descuento aplicado.
   Ejemplo: calcularPrecioDescuento(5000.0, 20.0) debe retornar 4000.0
            (5000 menos el 20% = 4000)
*/
float calcularPrecioDescuento(float precio, float descuento) {
    // TODO: completar
    return;
}


/* 10. RANGO NUMERICO
    Recibe un numero entero y retorna true si esta entre 1 y 100
    (ambos inclusive), o false en caso contrario.
    Ejemplo: estaEnRango(50) debe retornar true.
             estaEnRango(150) debe retornar false.
             estaEnRango(1) debe retornar true.
*/
bool estaEnRango(int numero) {
    // TODO: completar
    return;
}
