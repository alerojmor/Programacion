/* test_funciones.cpp
   IMPORTANTE: No modificar, borrar ni renombrar este archivo.

   Este archivo contiene los tests que se corren sobre tus funciones.
   Cada test verifica un caso de uso. Si el resultado que devuelve tu
   funcion coincide con el esperado, el test PASA. Si no, FALLA y se
   te muestra que se esperaba y que se obtuvo.

   Al final se imprime un resumen con la cantidad de tests pasados
   sobre el total.
*/

#include "funciones.cpp"
#include <iostream>
#include <cmath>
using namespace std;

// Contadores globales
int tests_pasados = 0;
int tests_totales = 0;


/* ---------- Helpers de testing ---------- */

// Compara dos enteros. Si son iguales, pasa el test. Si no, lo muestra.
void verificar_int(const string& nombre, int esperado, int obtenido) {
    tests_totales++;
    if (esperado == obtenido) {
        cout << "  [PASA] " << nombre << endl;
        tests_pasados++;
    } else {
        cout << "  [FALLA] " << nombre
             << "  -> esperado: " << esperado
             << ", obtenido: " << obtenido << endl;
    }
}

// Compara dos floats con cierta tolerancia (los floats casi nunca
// son exactamente iguales por como los guarda la computadora).
void verificar_float(const string& nombre, float esperado, float obtenido) {
    tests_totales++;
    float tolerancia = 0.01;
    if (fabs(esperado - obtenido) < tolerancia) {
        cout << "  [PASA] " << nombre << endl;
        tests_pasados++;
    } else {
        cout << "  [FALLA] " << nombre
             << "  -> esperado: " << esperado
             << ", obtenido: " << obtenido << endl;
    }
}

// Compara dos valores booleanos.
void verificar_bool(const string& nombre, bool esperado, bool obtenido) {
    tests_totales++;
    if (esperado == obtenido) {
        cout << "  [PASA] " << nombre << endl;
        tests_pasados++;
    } else {
        cout << "  [FALLA] " << nombre
             << "  -> esperado: " << (esperado ? "true" : "false")
             << ", obtenido: " << (obtenido ? "true" : "false") << endl;
    }
}


/* ---------- Tests por ejercicio ---------- */

void test_calcularCuadrado() {
    cout << "Ejercicio 1 - calcularCuadrado()" << endl;
    verificar_int("cuadrado de 5", 25, calcularCuadrado(5));
    verificar_int("cuadrado de 0", 0, calcularCuadrado(0));
    verificar_int("cuadrado de -3", 9, calcularCuadrado(-3));
    verificar_int("cuadrado de 10", 100, calcularCuadrado(10));
}

void test_maximoDeTres() {
    cout << "Ejercicio 2 - maximoDeTres()" << endl;
    verificar_int("el mayor es el del medio", 7, maximoDeTres(3, 7, 5));
    verificar_int("el mayor es el primero", 20, maximoDeTres(20, 5, 10));
    verificar_int("el mayor es el ultimo", 15, maximoDeTres(8, 12, 15));
    verificar_int("con numeros negativos", -1, maximoDeTres(-5, -3, -1));
}

void test_celsiusAFahrenheit() {
    cout << "Ejercicio 3 - celsiusAFahrenheit()" << endl;
    verificar_float("0 C son 32 F", 32.0, celsiusAFahrenheit(0.0));
    verificar_float("100 C son 212 F", 212.0, celsiusAFahrenheit(100.0));
    verificar_float("30 C son 86 F", 86.0, celsiusAFahrenheit(30.0));
    verificar_float("-40 C son -40 F", -40.0, celsiusAFahrenheit(-40.0));
}

void test_esPar() {
    cout << "Ejercicio 4 - esPar()" << endl;
    verificar_bool("4 es par", true, esPar(4));
    verificar_bool("7 no es par", false, esPar(7));
    verificar_bool("0 es par", true, esPar(0));
    verificar_bool("-6 es par", true, esPar(-6));
}

void test_aplicarIVA() {
    cout << "Ejercicio 5 - aplicarIVA()" << endl;
    verificar_float("100 con IVA = 121", 121.0, aplicarIVA(100.0));
    verificar_float("1000 con IVA = 1210", 1210.0, aplicarIVA(1000.0));
    verificar_float("0 con IVA = 0", 0.0, aplicarIVA(0.0));
    verificar_float("50 con IVA = 60.5", 60.5, aplicarIVA(50.0));
}

void test_obtenerPromedio() {
    cout << "Ejercicio 6 - obtenerPromedio()" << endl;
    verificar_float("promedio de 7,8,10", 8.333, obtenerPromedio(7, 8, 10));
    verificar_float("promedio de 10,10,10", 10.0, obtenerPromedio(10, 10, 10));
    verificar_float("promedio de 0,0,0", 0.0, obtenerPromedio(0, 0, 0));
    verificar_float("promedio de 4,5,6", 5.0, obtenerPromedio(4, 5, 6));
}

void test_determinarSigno() {
    cout << "Ejercicio 7 - determinarSigno()" << endl;
    verificar_int("5 es positivo", 1, determinarSigno(5));
    verificar_int("-3 es negativo", -1, determinarSigno(-3));
    verificar_int("0 es cero", 0, determinarSigno(0));
    verificar_int("100 es positivo", 1, determinarSigno(100));
}

void test_metrosAKilometros() {
    cout << "Ejercicio 8 - metrosAKilometros()" << endl;
    verificar_float("1500m = 1.5km", 1.5, metrosAKilometros(1500.0));
    verificar_float("1000m = 1km", 1.0, metrosAKilometros(1000.0));
    verificar_float("500m = 0.5km", 0.5, metrosAKilometros(500.0));
    verificar_float("0m = 0km", 0.0, metrosAKilometros(0.0));
}

void test_calcularPrecioDescuento() {
    cout << "Ejercicio 9 - calcularPrecioDescuento()" << endl;
    verificar_float("5000 con 20% off", 4000.0, calcularPrecioDescuento(5000.0, 20.0));
    verificar_float("1000 con 10% off", 900.0, calcularPrecioDescuento(1000.0, 10.0));
    verificar_float("100 con 50% off", 50.0, calcularPrecioDescuento(100.0, 50.0));
    verificar_float("200 con 0% off", 200.0, calcularPrecioDescuento(200.0, 0.0));
}

void test_estaEnRango() {
    cout << "Ejercicio 10 - estaEnRango()" << endl;
    verificar_bool("50 esta en rango", true, estaEnRango(50));
    verificar_bool("150 fuera de rango", false, estaEnRango(150));
    verificar_bool("1 esta en rango (limite)", true, estaEnRango(1));
    verificar_bool("100 esta en rango (limite)", true, estaEnRango(100));
    verificar_bool("0 fuera de rango", false, estaEnRango(0));
    verificar_bool("-5 fuera de rango", false, estaEnRango(-5));
}


/* ---------- Main ---------- */

int main() {
    cout << "==========================================" << endl;
    cout << "  Tests - Guia de ejercicios: Funciones" << endl;
    cout << "==========================================" << endl;
    cout << endl;

    test_calcularCuadrado();        cout << endl;
    test_maximoDeTres();            cout << endl;
    test_celsiusAFahrenheit();      cout << endl;
    test_esPar();                   cout << endl;
    test_aplicarIVA();              cout << endl;
    test_obtenerPromedio();         cout << endl;
    test_determinarSigno();         cout << endl;
    test_metrosAKilometros();       cout << endl;
    test_calcularPrecioDescuento(); cout << endl;
    test_estaEnRango();             cout << endl;

    cout << "==========================================" << endl;
    cout << "  RESUMEN: " << tests_pasados << " / " << tests_totales
         << " tests pasaron" << endl;

    if (tests_pasados == tests_totales) {
        cout << "  Felicitaciones, pasaste todos los tests!" << endl;
    } else {
        int fallidos = tests_totales - tests_pasados;
        cout << "  Te quedan " << fallidos << " test(s) por arreglar." << endl;
    }
    cout << "==========================================" << endl;

    return 0;
}
